import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Main — точка входа. Дружественное меню демонстрирует все задания лабораторной работы.
 *
 * Все исходные данные вводятся с клавиатуры там, где это логично; везде есть валидация.
 */
public final class Main {

    private final InputUtils inputUtils;
    private final PutPointUtil putPointUtil;

    public Main() {
        this.inputUtils = new InputUtils("stdin");
        this.putPointUtil = new PutPointUtil("Point placer");
    }

    public static void main(String[] args) {
        new Main().run();
    }

    private void run() {
        System.out.println("=== Лабораторная работа №4 — Дженерики и функциональные интерфейсы ===");

        boolean running = true;
        while (running) {
            printMenu();
            int choice = inputUtils.readIntInRange("Выберите пункт (0 — выход): ", 0, 6);
            System.out.println();
            switch (choice) {
                case 0:
                    running = false;
                    break;
                case 1:
                    demoBox();
                    break;
                case 2:
                    demoStorage();
                    break;
                case 3:
                    demoPutPoint();
                    break;
                case 4:
                    demoMap();
                    break;
                case 5:
                    demoFilter();
                    break;
                case 6:
                    demoReduce();
                    break;
                default:
                    System.out.println("Неверный выбор.");
            }
            System.out.println();
        }

        System.out.println("Программа завершена.");
    }

    private void printMenu() {
        System.out.println("Меню:");
        System.out.println("1 — Box<T>: положить Integer 3, передать в метод, извлечь и показать");
        System.out.println("2 — Storage<T>: демонстрация 4 кейсов (null/99/\"hello\" и альтернативы)");
        System.out.println("3 — PutPointUtil: положить Point3D в Box<? super Point3D>");
        System.out.println("4 — Map: 3 примера (строки->длины, ints->abs, arrays->max) — ввод данных");
        System.out.println("5 — Filter: 3 примера (строки, числа, массивы) — ввод данных");
        System.out.println("6 — Reduce: 3 примера (concat, sum, total elements) — ввод данных");
        System.out.println("0 — Выход");
    }

    // ---------------- Задание 1: Box ----------------
    private void demoBox() {
        System.out.println("--- Задание 1: Box<T> ---");
        Box<Integer> box = new Box<>();
        try {
            box.put(3); // строго по условию
            System.out.println("Положено в коробку: " + box);
        } catch (IllegalStateException e) {
            System.out.println("Ошибка при кладке: " + e.getMessage());
        }
        // Передача коробки в метод
        takeFromBoxAndPrint(box);
        System.out.println("После извлечения hasItem() = " + box.hasItem());
    }

    private void takeFromBoxAndPrint(Box<Integer> box) {
        Integer v = box.get();
        System.out.println("Извлечено из коробки: " + v);
    }

    // ---------------- Задание 2: Storage ----------------
    private void demoStorage() {
        System.out.println("--- Задание 2: Storage<T> ---");
        Storage<Integer> sNull = new Storage<>(null);
        System.out.println("Storage<Integer>(null) -> getOrElse(0): " + sNull.getOrElse(0));

        Storage<Integer> s99 = new Storage<>(99);
        System.out.println("Storage<Integer>(99) -> getOrElse(-1): " + s99.getOrElse(-1));

        Storage<String> sNullStr = new Storage<>(null);
        System.out.println("Storage<String>(null) -> getOrElse(\"default\"): " + sNullStr.getOrElse("default"));

        Storage<String> sHello = new Storage<>("hello");
        System.out.println("Storage<String>(\"hello\") -> getOrElse(\"hello world\"): " + sHello.getOrElse("hello world"));
    }

    // ---------------- Задание 3: PutPointUtil ----------------
    private void demoPutPoint() {
        System.out.println("--- Задание 3: putRandomPoint(Box<? super Point3D>) ---");
        Box<Object> box = new Box<>();
        putPointUtil.putRandomPoint(box);
        System.out.println("После putRandomPoint содержимое коробки: " + box);
        Object extracted = box.get();
        System.out.println("Извлечено из коробки: " + extracted);
    }

    // ---------------- Задание 4: Map ----------------
    private void demoMap() {
        System.out.println("--- Задание 4: map — примеры ---");

        // 4.1 Strings -> lengths
        int n = inputUtils.readIntInRange("Часть 1: введите количество строк (0..1000): ", 0, 1000);
        List<String> strings = inputUtils.readStringList("Введите строки:", n);
        List<Integer> lengths = GenericUtils.map(strings, String::length);
        System.out.println("Длины строк: " + lengths);

        // 4.2 Integers -> abs
        int m = inputUtils.readIntInRange("\nЧасть 2: введите количество целых чисел (0..1000): ", 0, 1000);
        List<Integer> ints = new ArrayList<>();
        for (int i = 0; i < m; i++) {
            ints.add(inputUtils.readInt(String.format("  Введите целое %d/%d: ", i + 1, m)));
        }
        List<Integer> absList = GenericUtils.map(ints, x -> x < 0 ? -x : x);
        System.out.println("Преобразованные (abs): " + absList);

        // 4.3 arrays -> max
        int k = inputUtils.readIntInRange("\nЧасть 3: введите количество массивов (0..100): ", 0, 100);
        List<int[]> arrays = new ArrayList<>();
        for (int i = 0; i < k; i++) {
            int len = inputUtils.readIntInRange(String.format("  Длина массива %d: ", i + 1), 0, 10000);
            int[] arr = inputUtils.readIntArray("  Ввод элементов массива:", len);
            arrays.add(arr);
        }
        List<Integer> maxes = GenericUtils.map(arrays, arr -> {
            if (arr == null || arr.length == 0) return Integer.MIN_VALUE;
            int max = arr[0];
            for (int v : arr) if (v > max) max = v;
            return max;
        });
        System.out.println("Максимумы для каждого массива: " + maxes);
    }

    // ---------------- Задание 5: Filter ----------------
    private void demoFilter() {
        System.out.println("--- Задание 5: filter — примеры ---");

        // 5.1 strings: remove strings with length < 3
        int n = inputUtils.readIntInRange("Часть 1: введите количество строк (0..1000): ", 0, 1000);
        List<String> strings = inputUtils.readStringList("Введите строки:", n);
        List<String> filteredStrings = GenericUtils.filter(strings, s -> s != null && s.length() >= 3);
        System.out.println("Результат: " + filteredStrings);

        // 5.2 integers: remove positive (keep <=0)
        int m = inputUtils.readIntInRange("\nЧасть 2: введите количество чисел (0..1000): ", 0, 1000);
        List<Integer> numbers = new ArrayList<>();
        for (int i = 0; i < m; i++) {
            numbers.add(inputUtils.readInt(String.format("  Число %d/%d: ", i + 1, m)));
        }
        List<Integer> nonPositive = GenericUtils.filter(numbers, x -> x <= 0);
        System.out.println("Результат (<=0): " + nonPositive);

        // 5.3 arrays: keep arrays with no positive elements
        int k = inputUtils.readIntInRange("\nЧасть 3: введите количество массивов (0..100): ", 0, 100);
        List<int[]> arrays = new ArrayList<>();
        for (int i = 0; i < k; i++) {
            int len = inputUtils.readIntInRange(String.format("  Длина массива %d: ", i + 1), 0, 10000);
            int[] arr = inputUtils.readIntArray("  Ввод элементов массива:", len);
            arrays.add(arr);
        }
        List<int[]> filtered = GenericUtils.filter(arrays, arr -> {
            if (arr == null) return false;
            for (int v : arr) if (v > 0) return false;
            return true;
        });
        System.out.println("Массивы без положительных элементов:");
        for (int[] a : filtered) System.out.println(Arrays.toString(a));
    }

    // ---------------- Задание 6: Reduce ----------------
    private void demoReduce() {
        System.out.println("--- Задание 6: reduce/safeReduce ---");

        // 6.1 concat strings
        int n = inputUtils.readIntInRange("Часть 1: введите количество строк (0..1000): ", 0, 1000);
        List<String> strings = inputUtils.readStringList("Введите строки:", n);
        String concat = GenericUtils.safeReduce(strings, () -> "", (a, b) -> a + b);
        System.out.println("Результат конкатенации: " + concat);

        // 6.2 sum integers
        int m = inputUtils.readIntInRange("\nЧасть 2: введите количество чисел (0..1000): ", 0, 1000);
        List<Integer> numbers = new ArrayList<>();
        for (int i = 0; i < m; i++) {
            numbers.add(inputUtils.readInt(String.format("  Число %d/%d: ", i + 1, m)));
        }
        Integer sum = GenericUtils.safeReduce(numbers, () -> 0, Integer::sum);
        System.out.println("Сумма: " + sum);

        // 6.3 list of lists: total elements count
        int k = inputUtils.readIntInRange("\nЧасть 3: введите количество вложенных списков (0..100): ", 0, 100);
        List<List<Integer>> listOfLists = new ArrayList<>();
        for (int i = 0; i < k; i++) {
            int len = inputUtils.readIntInRange(String.format("  Длина вложенного списка %d: ", i + 1), 0, 10000);
            List<Integer> inner = new ArrayList<>();
            for (int j = 0; j < len; j++) {
                inner.add(inputUtils.readInt(String.format("    Элемент %d/%d: ", j + 1, len)));
            }
            listOfLists.add(inner);
        }
        List<Integer> sizes = GenericUtils.map(listOfLists, List::size);
        Integer total = GenericUtils.safeReduce(sizes, () -> 0, Integer::sum);
        System.out.println("Общее количество элементов во всех списках: " + total);
    }
}
