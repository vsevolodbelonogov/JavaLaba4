import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * InputUtils — утилиты безопасного ввода с консоли.
 *
 * Объект хранит Scanner и имя источника; методы защищают ввод от некорректных значений.
 */
public final class InputUtils {

    private final String sourceName;
    private final Scanner scanner;

    /**
     * Конструктор.
     *
     * @param sourceName имя источника (например "stdin")
     */
    public InputUtils(String sourceName) {
        this.sourceName = sourceName;
        this.scanner = new Scanner(System.in);
    }

    /**
     * Читает целое число. Повторяет запрос до корректного ввода.
     *
     * @param prompt приглашение
     * @return введённое целое число
     */
    public int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine();
            try {
                return Integer.parseInt(line.trim());
            } catch (NumberFormatException e) {
                System.out.println("Неверный ввод. Введите целое число.");
            }
        }
    }

    /**
     * Читает целое число в диапазоне [min, max]. Повторяет запрос до корректного ввода.
     *
     * @param prompt приглашение
     * @param min    минимальное значение (включительно)
     * @param max    максимальное значение (включительно)
     * @return введённое целое в диапазоне
     */
    public int readIntInRange(String prompt, int min, int max) {
        while (true) {
            int v = readInt(prompt);
            if (v < min || v > max) {
                System.out.printf("Число должно быть в диапазоне [%d, %d].%n", min, max);
                continue;
            }
            return v;
        }
    }

    /**
     * Читает строку (включая пустую).
     *
     * @param prompt приглашение
     * @return введённая строка
     */
    public String readLine(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine();
    }

    /**
     * Читает список строк длины n.
     *
     * @param prompt приглашение перед вводом списка
     * @param n      количество строк (>=0)
     * @return список строк
     */
    public List<String> readStringList(String prompt, int n) {
        List<String> list = new ArrayList<>();
        System.out.println(prompt);
        for (int i = 0; i < n; i++) {
            list.add(readLine(String.format("  [%d/%d]: ", i + 1, n)));
        }
        return list;
    }

    /**
     * Читает массив int длины n (n >= 0).
     *
     * @param prompt приглашение
     * @param n      размер массива
     * @return массив int
     */
    public int[] readIntArray(String prompt, int n) {
        System.out.println(prompt);
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = readInt(String.format("  Элемент %d/%d: ", i + 1, n));
        }
        return arr;
    }

    @Override
    public String toString() {
        return "InputUtils{sourceName='" + sourceName + "'}";
    }
}
