/**
 * Tester<T> — функциональный интерфейс-предикат.
 */
@FunctionalInterface
public interface Tester<T> {
    /**
     * Проверяет, удовлетворяет ли значение условию.
     *
     * @param value проверяемое значение
     * @return true — если условие выполнено, иначе false
     */
    boolean test(T value);
}
