import java.util.Objects;

/**
 * PutPointUtil — пример метода с wildcard: принимает Box<? super Point3D>
 * и кладёт туда Point3D. Класс содержит поле description и toString().
 */
public final class PutPointUtil {

    private final String description;

    /**
     * Конструктор.
     *
     * @param description описание утилиты
     */
    public PutPointUtil(String description) {
        this.description = Objects.requireNonNull(description);
    }

    /**
     * Создаёт случайную точку и кладёт в коробку.
     *
     * @param box коробка, допускающая Point3D или его супертайп
     */
    public void putRandomPoint(Box<? super Point3D> box) {
        Point3D p = new Point3D(Math.round(Math.random() * 1000) / 100.0,
                Math.round(Math.random() * 1000) / 100.0,
                Math.round(Math.random() * 1000) / 100.0);
        box.put(p);
    }

    @Override
    public String toString() {
        return "PutPointUtil{description='" + description + "'}";
    }
}
