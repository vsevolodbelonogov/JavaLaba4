import java.util.Objects;

/**
 * Point3D — неизменяемая трёхмерная точка.
 */
public final class Point3D {

    private final double x;
    private final double y;
    private final double z;

    /**
     * Создать точку.
     *
     * @param x координата X
     * @param y координата Y
     * @param z координата Z
     */
    public Point3D(double x, double y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getZ() {
        return z;
    }

    @Override
    public String toString() {
        return String.format("Point3D{x=%.3f, y=%.3f, z=%.3f}", x, y, z);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Point3D)) return false;
        Point3D other = (Point3D) obj;
        return Double.compare(x, other.x) == 0
                && Double.compare(y, other.y) == 0
                && Double.compare(z, other.z) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(x, y, z);
    }
}
