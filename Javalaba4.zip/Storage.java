import java.util.function.Supplier;

/**
 * Storage<T> — неизменяемое хранилище одного объекта.
 *
 * Характеристики:
 * - Значение задаётся только в конструкторе (может быть null).
 * - getOrElse / getOrElseGet возвращают альтернативу, если сохранено null.
 */
public final class Storage<T> {

    private final T value;

    /**
     * Конструктор.
     *
     * @param value значение для хранения (возможно null)
     */
    public Storage(T value) {
        this.value = value;
    }

    /**
     * Вернуть сохранённое значение (может быть null).
     *
     * @return сохранённое значение
     */
    public T get() {
        return value;
    }

    /**
     * Вернуть значение или альтернативу, если значение == null.
     *
     * @param alternative альтернатива
     * @return value или alternative
     */
    public T getOrElse(T alternative) {
        return value != null ? value : alternative;
    }

    /**
     * Вернуть значение или результат supplier, если value == null.
     *
     * @param supplier поставщик альтернативы
     * @return value или supplier.get()
     */
    public T getOrElseGet(Supplier<T> supplier) {
        return value != null ? value : supplier.get();
    }

    @Override
    public String toString() {
        return "Storage{" + "value=" + value + '}';
    }
}
