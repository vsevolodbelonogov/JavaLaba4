import java.util.Objects;

/**
 * Box<T> — обобщённая коробка, хранящая ровно один объект типа T.
 *
 * Правила:
 * - put(T) помещает объект только если коробка пуста; иначе выбрасывается IllegalStateException.
 * - get() возвращает объект и обнуляет ссылку внутри коробки.
 * - hasItem()/isEmpty() для проверки состояния.
 */
public final class Box<T> {

    private T item;

    /**
     * Создаёт пустую коробку.
     */
    public Box() {
        this.item = null;
    }

    /**
     * Создаёт коробку с начальным значением (может быть null).
     *
     * @param initial начальное значение
     */
    public Box(T initial) {
        this.item = initial;
    }

    /**
     * Помещает объект в коробку. Если коробка уже содержит объект — бросает IllegalStateException.
     *
     * @param value объект для помещения
     * @throws IllegalStateException если коробка уже занята
     */
    public void put(T value) {
        if (hasItem()) {
            throw new IllegalStateException("Коробка уже занята");
        }
        this.item = value;
    }

    /**
     * Извлекает объект из коробки и обнуляет ссылку внутри коробки.
     *
     * @return извлечённый объект (или null если коробка была пуста)
     */
    public T get() {
        T tmp = item;
        item = null;
        return tmp;
    }

    /**
     * Возвращает true, если в коробке хранится объект (не null).
     *
     * @return true, если есть объект
     */
    public boolean hasItem() {
        return item != null;
    }

    /**
     * Возвращает true, если коробка пуста.
     *
     * @return true если пусто
     */
    public boolean isEmpty() {
        return item == null;
    }

    @Override
    public String toString() {
        return isEmpty() ? "Box{empty}" : "Box{item=" + Objects.toString(item) + "}";
    }
}
