/**
 * Mapper<T, R> — функциональный интерфейс для преобразования элемента типа T в R.
 */
@FunctionalInterface
public interface Mapper<T, R> {
    /**
     * Преобразовать значение типа T в значение типа R.
     *
     * @param value входное значение
     * @return преобразованное значение
     */
    R map(T value);
}
