/**
 * Reducer<T> — функциональный интерфейс для объединения двух значений в одно.
 */
@FunctionalInterface
public interface Reducer<T> {
    /**
     * Объединяет два значения в одно.
     *
     * @param a первый аргумент
     * @param b второй аргумент
     * @return результат объединения
     */
    T reduce(T a, T b);
}
