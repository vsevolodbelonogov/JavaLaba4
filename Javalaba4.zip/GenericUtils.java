import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Supplier;

/**
 * GenericUtils — набор обобщённых утилит: map, filter, reduce, safeReduce.
 *
 * Каждый метод полностью реализован и не вызывает raw-types.
 */
public final class GenericUtils {

    private final String name;

    /**
     * Экземплярный конструктор — класс хранит поле name для соответсвия ТЗ (поле/конструктор/toString()).
     *
     * @param name имя
     */
    public GenericUtils(String name) {
        this.name = Objects.requireNonNull(name);
    }

    /** Без-аргументный конструктор. */
    public GenericUtils() {
        this.name = "GenericUtils";
    }

    /**
     * Применяет mapper ко всем элементам и возвращает новый список результатов.
     *
     * @param list   исходный список
     * @param mapper функция преобразования
     * @param <T>    тип входного списка
     * @param <R>    тип выходного списка
     * @return список преобразованных значений (пустой список, если list == null)
     */
    public static <T, R> List<R> map(List<T> list, Mapper<T, R> mapper) {
        List<R> result = new ArrayList<>();
        if (list == null || mapper == null) {
            return result;
        }
        for (T item : list) {
            result.add(mapper.map(item));
        }
        return result;
    }

    /**
     * Фильтрует список, возвращая только элементы, для которых tester.test == true.
     *
     * @param list   исходный список
     * @param tester тестирующая функция
     * @param <T>    тип элементов
     * @return новый список (пустой если list == null)
     */
    public static <T> List<T> filter(List<T> list, Tester<T> tester) {
        List<T> result = new ArrayList<>();
        if (list == null || tester == null) {
            return result;
        }
        for (T item : list) {
            if (tester.test(item)) {
                result.add(item);
            }
        }
        return result;
    }

    /**
     * Сворачивает список в одно значение, начиная с identity.
     *
     * @param list     исходный список
     * @param identity начальное значение
     * @param reducer  логика объединения
     * @param <T>      тип элементов
     * @return агрегированное значение (identity если list == null)
     */
    public static <T> T reduce(List<T> list, T identity, Reducer<T> reducer) {
        T acc = identity;
        if (list == null || reducer == null) {
            return acc;
        }
        for (T item : list) {
            acc = reducer.reduce(acc, item);
        }
        return acc;
    }

    /**
     * Безопасный reduce: если список пуст или null — возвращает identitySupplier.get().
     *
     * @param list             исходный список
     * @param identitySupplier поставщик значения по умолчанию
     * @param reducer          логика свёртки
     * @param <T>              тип элементов
     * @return агрегированное значение
     */
    public static <T> T safeReduce(List<T> list, Supplier<T> identitySupplier, Reducer<T> reducer) {
        if (identitySupplier == null || reducer == null) {
            throw new IllegalArgumentException("identitySupplier and reducer must not be null");
        }
        T acc = identitySupplier.get();
        if (list == null || list.isEmpty()) {
            return acc;
        }
        for (T item : list) {
            acc = reducer.reduce(acc, item);
        }
        return acc != null ? acc : identitySupplier.get();
    }

    @Override
    public String toString() {
        return "GenericUtils{name='" + name + "'}";
    }
}
